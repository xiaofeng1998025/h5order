import Vue from 'vue'
import Vant, { Locale } from 'vant'
import 'vant/lib/index.css'

Vue.use(Vant)
